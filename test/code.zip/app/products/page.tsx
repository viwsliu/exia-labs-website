import Sidebar from "@/components/Sidebar"
import ProductItem from "@/components/products/ProductItem"
import Footer from "@/components/Footer"
import "@/styles/products.css"

const products = [
  {
    id: "product1",
    title: "Blue",
    description:
      "Improve decision-making for warfighters. Suite of decision-support products that generate and wargame tactical echelon courses of action (COAs). Planning workflows could be tied to operations orders or users could place units in a sandbox in time and space. The sandbox wargaming feature leverages multiple models (including COFM), in order to produce a feasible, acceptable, and suitable COA. Currently optimized for Army brigades and battalions.",
    image: "/images/blue_sandbox.png",
    link: "https://www.youtube.com/watch?v=ZHJPGVRdcLs",
    imagePosition: "right",
  },
  {
    id: "product2",
    title: "Recon",
    description:
      "Improve decision-making by analyzing the neutral operational environment: terrain, weather, and time. A cloud-based Intelligence Preparation of the Operational Environment AI agent that creates decision support products like the Modified Combined Obstacle Overlay, identifies key terrain such as tactical areas for Position Areas for Artillery, Logistics Resupply Points and generates maneuver and logistics routes based on specific formations (e.g. Stryker Battalion, Mobile Infantry Company, Armor Brigade).",
    image: "/images/recon.jpg",
    link: "https://example.com/cloudsync",
    imagePosition: "left",
  },
  {
    id: "product3",
    title: "Soraka",
    description:
      'Improve decision-making locally at the tactical edge. Data ecosystem "in a box" that enables data science at the tactical edge. Warfighters are able to process massive amounts of sensor data locally, without the need to transmit data to higher headquarters. Local processing allows for faster analysis and better decision-making in contested environments.',
    image: "/images/soraka.png",
    link: "https://www.army.mil/article/288299/army_selects_six_winners_in_xtech_ai_grand_challenge_competition",
    imagePosition: "right",
  },
  {
    id: "product4",
    title: "Viktor",
    description:
      "Improve decision-making for humanoid robots. Humanoid robot simulation platform built on a commercial game engine. Simulates Army individual and collective warrior tasks through a digital twin that mirrors physical robot actions and tasks. Takes generated COAs from Blue and simulates them at the individual level, ensuring robots not only execute tasks but also understand how their actions nest within higher-echelon missions.",
    image: "/images/viktor.png",
    link: "",
    imagePosition: "left",
  },
]

export default function ProductsPage() {
  return (
    <>
      <Sidebar currentPath="/products" />
      <div className="main-content">
        <section className="page-header">
          <div className="container"></div>
        </section>

        <section className="products-section">
          <div className="container">
            <div className="products-title-wrapper">
              <h1 className="products-page-title">Our Products</h1>
            </div>

            <hr className="section-divider" />

            {products.map((product, index) => (
              <div key={product.id}>
                <ProductItem {...product} />
                {index < products.length - 1 && <hr className="section-divider" />}
              </div>
            ))}
          </div>
        </section>

        <Footer />
      </div>
    </>
  )
}
