'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import styles from './Sidebar.module.css'

interface SidebarProps {
  currentPage?: 'home' | 'products' | 'about'
}

export default function Sidebar({ currentPage = 'home' }: SidebarProps) {
  const [isActive, setIsActive] = useState(false)

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const sidebar = document.querySelector(`.${styles.sidebarNav}`)
      const hamburger = document.querySelector(`.${styles.hamburger}`)
      
      if (isActive && sidebar && hamburger && 
          !sidebar.contains(target) && !hamburger.contains(target)) {
        setIsActive(false)
      }
    }

    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [isActive])

  const closeSidebar = () => setIsActive(false)

  return (
    <>
      <button 
        className={styles.hamburger} 
        aria-label="Toggle navigation"
        onClick={() => setIsActive(!isActive)}
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav className={`${styles.sidebarNav} ${isActive ? styles.active : ''}`}>
        <Link href="/" className={styles.sidebarLogo}>
          <img src="/images/exialabs_logo.jpg" alt="Exia Labs Logo" className={styles.sidebarLogoImg} />
          <span>Exia Labs</span>
        </Link>
        <ul className={styles.sidebarMenu}>
          <li>
            <Link 
              href="/" 
              className={currentPage === 'home' ? styles.active : ''}
              onClick={closeSidebar}
            >
              Home
            </Link>
            <ul className={styles.sidebarSubmenu}>
              <li><Link href="/#mission" onClick={closeSidebar}>Our Mission</Link></li>
            </ul>
            <ul className={styles.sidebarSubmenu}>
              <li><Link href="/#impact" onClick={closeSidebar}>Our Impact</Link></li>
            </ul>
            <ul className={styles.sidebarSubmenu}>
              <li><Link href="/#gallery" onClick={closeSidebar}>News</Link></li>
            </ul>
          </li>
          <li>
            <Link 
              href="/products" 
              className={currentPage === 'products' ? styles.active : ''}
              onClick={closeSidebar}
            >
              Products
            </Link>
          </li>
          <li>
            <Link 
              href="/about" 
              className={currentPage === 'about' ? styles.active : ''}
              onClick={closeSidebar}
            >
              About
            </Link>
            <ul className={styles.sidebarSubmenu}>
              <li><Link href="/about#mission" onClick={closeSidebar}>Our Mission</Link></li>
            </ul>
            <ul className={styles.sidebarSubmenu}>
              <li><Link href="/about#impact" onClick={closeSidebar}>Our Impact</Link></li>
            </ul>
            <ul className={styles.sidebarSubmenu}>
              <li><Link href="/about#team" onClick={closeSidebar}>Our Team</Link></li>
            </ul>
          </li>
          <li>
            <a 
              href="https://blog.exialabs.com/" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              Blog 
              <svg style={{ width: '14px', height: '14px', display: 'inline-block', verticalAlign: 'middle', marginLeft: '4px' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                <polyline points="15 3 21 3 21 9"></polyline>
                <line x1="10" y1="14" x2="21" y2="3"></line>
              </svg>
            </a>
          </li>
        </ul>
      </nav>
    </>
  )
}
