'use client'

import { useState, useEffect } from 'react'
import styles from './Slideshow.module.css'

interface Slide {
  id: string
  image: string
  alt: string
  caption: string
}

const slides: Slide[] = [
  {
    id: 'blue',
    image: '/images/blue_sandbox.png',
    alt: 'Blue',
    caption: 'Blue',
  },
  {
    id: 'recon',
    image: '/images/recon.jpg',
    alt: 'Recon',
    caption: 'Recon',
  },
  {
    id: 'soraka',
    image: '/images/soraka.png',
    alt: 'Soraka',
    caption: 'Soraka',
  },
  {
    id: 'viktor',
    image: '/images/viktor.png',
    alt: 'Viktor',
    caption: 'Viktor',
  },
]

export default function Slideshow() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const showSlide = (index: number) => {
    setCurrentSlide(index)
  }

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  return (
    <div className={styles.productSlideshow}>
      <div className={styles.slideshowContainer}>
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`${styles.slide} ${index === currentSlide ? styles.active : ''}`}
          >
            <img src={slide.image || "/placeholder.svg"} alt={slide.alt} />
            <div className={styles.slideCaption}>
              <h3>{slide.caption}</h3>
            </div>
          </div>
        ))}

        <a className={styles.prev} onClick={prevSlide}>❮</a>
        <a className={styles.next} onClick={nextSlide}>❯</a>
      </div>
      <div className={styles.slideshowDots}>
        {slides.map((_, index) => (
          <span
            key={index}
            className={`${styles.dot} ${index === currentSlide ? styles.active : ''}`}
            onClick={() => showSlide(index)}
          />
        ))}
      </div>
    </div>
  )
}
