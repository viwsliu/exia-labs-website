import Sidebar from '@/components/Sidebar'
import ScrollAnimations from '@/components/ScrollAnimations'
import Slideshow from '@/components/Slideshow'
import styles from './home.module.css'

export default function Home() {
  return (
    <>
      <Sidebar currentPage="home" />
      <ScrollAnimations />
      
      <div className={styles.mainContent}>
        {/* Hero Section */}
        <section className={`${styles.hero} ${styles.heroFadeIn}`}>
          <div className={styles.heroContent}>
            <div className={styles.heroLogo}>
              <div className={styles.productLogo}>
                <img src="/images/exialabs_logo.jpg" alt="Exia Labs Logo" />
              </div>
            </div>
            <div className={styles.heroText}>
              <h1>Exia Labs</h1>
              <p className={styles.missionStatement}>
                Generating Warfighting Strategies Beyond Human Limits
              </p>
            </div>
          </div>
          <a href="#vision" className={styles.scrollArrow}>
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </a>
        </section>

        {/* Vision Section */}
        <section id="vision" className={styles.visionSection}>
          <div className={styles.visionOverlay}>
            <div className={styles.visionContent}>
              <h2 className={styles.visionHeading}>ADVANCING DEFENSE<br />TECHNOLOGY</h2>
              <p className={styles.visionText}>Our cutting-edge systems are transforming how soldiers approach operations with innovative AI-driven solutions.</p>
              <a href="/products" className={styles.visionButton}>EXPLORE <span>→</span></a>
            </div>
          </div>
          <a href="#vision2" className={styles.scrollArrow}>
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </a>
        </section>

        <section id="vision2" className={styles.visionSectionAlt}>
          <div className={styles.visionOverlayAlt}>
            <div className={styles.visionContentAlt}>
              <h2 className={styles.visionHeading}>SUPPORTING WARFIGHTERS<br />ON THE GROUND</h2>
              <p className={styles.visionText}>Exia Labs is dedicated to empowering warfighters with advanced AI tools that enhance situational awareness and decision-making in the field.</p>
              <a href="/products" className={styles.visionButton}>EXPLORE <span>→</span></a>
            </div>
          </div>
          <a href="#vision3" className={styles.scrollArrow}>
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </a>
        </section>

        <section id="vision3" className={styles.visionSection3}>
          <div className={styles.visionOverlay}>
            <div className={styles.visionContent}>
              <h2 className={styles.visionHeading}>DELIVERING<br /> DECISION ADVANTAGE</h2>
              <p className={styles.visionText}>Exia Labs is pioneering AI-powered solutions that enhance strategic decision-making and operational effectiveness for warfighters.</p>
              <a href="/products" className={styles.visionButton}>EXPLORE <span>→</span></a>
            </div>
          </div>
          <a href="#footer" className={styles.scrollArrow}>
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </a>
        </section>

        <footer id="footer" className="footer">
          <hr className="section-divider" />
          <div className="container">
            <p>&copy; 2025 Exia Labs</p>
          </div>
        </footer>
      </div>
    </>
  )
}
