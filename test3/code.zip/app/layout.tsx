import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Exia Labs',
  description: 'Generating Warfighting Strategies Beyond Human Limits',
  icons: {
    icon: '/images/favicon.png',
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700;800;900&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
