import Sidebar from '@/components/Sidebar'
import ScrollAnimations from '@/components/ScrollAnimations'
import styles from './about.module.css'

export const metadata = {
  title: 'Exia Labs - About',
  description: 'Learn about our mission, impact, team, and backers',
}

export default function About() {
  return (
    <>
      <Sidebar currentPage="about" />
      <ScrollAnimations />
      
      <div className={styles.mainContent}>
        <section className={styles.pageHeader}>
          <div className="container"></div>
        </section>

        {/* Mission Section */}
        <section id="mission" className={styles.missionSection}>
          <div className="container">
            <h2 className="section-title slide-up">Our Mission</h2>
            <div className={styles.missionContent}>
              <div className={`${styles.missionTextContainer} slide-up`}>
                <p className={styles.missionText}>
                  Example mission statement text goes here. Example text something. <br />
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <p className={styles.missionText}>
                  Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
                </p>
              </div>
              <div className={`${styles.missionVideo} slide-up`}>
                <video controls poster="/images/blue_intro.png">
                  <source src="/images/blue_vid.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              </div>
            </div>
          </div>
        </section>

        <hr className="section-divider" />

        {/* Impact Section */}
        <section id="impact" className={styles.missionSection}>
          <div className="container">
            <h2 className="section-title slide-up">Our Impact</h2>
            <div className={`${styles.missionContent} ${styles.missionContentReverse}`}>
              <div className={`${styles.missionTextContainer} slide-up`}>
                <p className={styles.missionText}>
                  Our impact extends across defense and intelligence communities. Example impact statement text goes here. <br />
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
                <p className={styles.missionText}>
                  We are transforming how warfighters make critical decisions through advanced AI systems. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
              </div>
              <div className={`${styles.missionVideo} slide-up`}>
                <video controls poster="/images/blue_intro.png">
                  <source src="/images/blue_vid.mp4" type="video/mp4" />
                  Your browser does not support the video tag.
                </video>
              </div>
            </div>
          </div>
        </section>

        <hr className="section-divider" />

        {/* Team Section */}
        <section id="team" className={styles.teamSection}>
          <div className="container">
            <h2 className="section-title slide-up">Our Team</h2>
            <div className={styles.teamGrid}>
              <div className={`${styles.teamMember} slide-up`}>
                <div className={styles.memberImage}>
                  <img src="/images/people/jon.png" alt="Jonathan Pan" />
                </div>
                <h3>Jonathan Pan</h3>
                <p className={styles.memberRole}>CEO & Co-founder</p>
                <div className={styles.memberLinks}>
                  <a href="https://www.linkedin.com/in/jonpan/" target="_blank" rel="noopener noreferrer">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                  </a>
                  <a href="https://x.com/notvert" target="_blank" rel="noopener noreferrer">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                      <polyline points="15 3 21 3 21 9"></polyline>
                      <line x1="10" y1="14" x2="21" y2="3"></line>
                    </svg>
                  </a>
                </div>
              </div>

              <div className={`${styles.teamMember} slide-up`}>
                <div className={styles.memberImage}>
                  <img src="/images/people/serj.png" alt="Serj Kazar" />
                </div>
                <h3>Serj Kazar</h3>
                <p className={styles.memberRole}>CTO & Co-founder</p>
                <div className={styles.memberLinks}>
                  <a href="https://www.linkedin.com/in/serjkazar/" target="_blank" rel="noopener noreferrer">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                  </a>
                </div>
              </div>

              <div className={`${styles.teamMember} slide-up`}>
                <div className={styles.memberImage}>
                  <img src="/images/people/connor.png" alt="Connor Walsh" />
                </div>
                <h3>Connor Walsh</h3>
                <p className={styles.memberRole}>Founding Engineer</p>
                <div className={styles.memberLinks}>
                  <a href="https://www.linkedin.com/in/connor-walsh-0812a395/" target="_blank" rel="noopener noreferrer">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                  </a>
                </div>
              </div>

              <div className={`${styles.teamMember} slide-up`}>
                <div className={styles.memberImage}>
                  <img src="/images/people/abby.png" alt="Abby Beizer" />
                </div>
                <h3>Abby Beizer</h3>
                <p className={styles.memberRole}>Software Engineer</p>
                <div className={styles.memberLinks}>
                  <a href="https://linkedin.com/" target="_blank" rel="noopener noreferrer">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                  </a>
                </div>
              </div>

              <div className={`${styles.teamMember} slide-up`}>
                <div className={styles.memberImage}>
                  <img src="/images/people/john.png" alt="John Herman" />
                </div>
                <h3>John Herman</h3>
                <p className={styles.memberRole}>Head of Mission Partners</p>
                <div className={styles.memberLinks}>
                  <a href="https://www.linkedin.com/in/john-j-herrman/" target="_blank" rel="noopener noreferrer">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        <hr className="section-divider" />

        {/* Investors Section */}
        <section className={styles.investorsSection}>
          <div className="container">
            <h2 className="section-title slide-up">Our Backers</h2>
            <div className={styles.investorsGrid}>
              <div className={`${styles.investorCard} slide-up`}>
                <img src="/images/backers/a1.svg" alt="Venture Partners" />
              </div>
              <div className={`${styles.investorCard} slide-up`}>
                <img src="/images/backers/anorak.png" alt="Growth Capital" />
              </div>
              <div className={`${styles.investorCard} slide-up`}>
                <img src="/images/backers/mv.svg" alt="Tech Investors" />
              </div>
              <div className={`${styles.investorCard} slide-up`}>
                <img src="/images/backers/pathbreaker.png" alt="Angel Network" />
              </div>
              <div className={`${styles.investorCard} slide-up`}>
                <img src="/images/backers/space_capital.png" alt="Innovation Fund" />
              </div>
            </div>
          </div>
        </section>

        <footer className="footer">
          <hr className="section-divider" />
          <div className="container">
            <p>&copy; 2025 Exia Labs</p>
          </div>
        </footer>
      </div>
    </>
  )
}
