import Sidebar from '@/components/Sidebar'
import ScrollAnimations from '@/components/ScrollAnimations'
import styles from './products.module.css'

export const metadata = {
  title: 'Exia Labs - Products',
  description: 'Our cutting-edge AI-powered defense technology products',
}

export default function Products() {
  return (
    <>
      <Sidebar currentPage="products" />
      <ScrollAnimations />
      
      <div className={styles.mainContent}>
        <section className={styles.pageHeader}>
          <div className="container"></div>
        </section>

        <section className={styles.productsSection}>
          <div className="container">
            <div className={styles.productsTitleWrapper}>
              <h1 className={styles.productsPageTitle}>Our Products</h1>
            </div>

            <hr className="section-divider" />

            {/* Product 1: Blue */}
            <div id="product1" className={`${styles.productSection} slide-up`}>
              <div className={styles.productContentAlt}>
                <div className={styles.productTextContent}>
                  <h2>Blue</h2>
                  <p className={styles.productDescription}>
                    Improve decision-making for warfighters. Suite of decision-support products that generate and wargame tactical echelon courses of action (COAs). Planning workflows could be tied to operations orders or users could place units in a sandbox in time and space. The sandbox wargaming feature leverages multiple models (including COFM), in order to produce a feasible, acceptable, and suitable COA. Currently optimized for Army brigades and battalions.
                  </p>
                  <a href="https://www.youtube.com/watch?v=ZHJPGVRdcLs" target="_blank" rel="noopener noreferrer" className="cta-button">LEARN MORE</a>
                </div>
                <div className={styles.productImagesSingle}>
                  <img src="/images/blue_sandbox.png" alt="" className={styles.productSingleImage} />
                </div>
              </div>
            </div>

            <hr className="section-divider" />

            {/* Product 2: Recon */}
            <div id="product2" className={`${styles.productSection} slide-up`}>
              <div className={styles.productContentAlt}>
                <div className={styles.productImagesSingle}>
                  <img src="/images/recon.jpg" alt="" className={styles.productSingleImage} />
                </div>
                <div className={styles.productTextContent}>
                  <h2>Recon</h2>
                  <p className={styles.productDescription}>
                    Improve decision-making by analyzing the neutral operational environment: terrain, weather, and time. A cloud-based Intelligence Preparation of the Operational Environment AI agent that creates decision support products like the Modified Combined Obstacle Overlay, identifies key terrain such as tactical areas for Position Areas for Artillery, Logistics Resupply Points and generates maneuver and logistics routes based on specific formations (e.g. Stryker Battalion, Mobile Infantry Company, Armor Brigade).
                  </p>
                  <a href="https://example.com/cloudsync" target="_blank" rel="noopener noreferrer" className="cta-button">LEARN MORE</a>
                </div>
              </div>
            </div>

            <hr className="section-divider" />

            {/* Product 3: Soraka */}
            <div id="product3" className={`${styles.productSection} slide-up`}>
              <div className={styles.productContentAlt}>
                <div className={styles.productTextContent}>
                  <h2>Soraka</h2>
                  <p className={styles.productDescription}>
                    Improve decision-making locally at the tactical edge. Data ecosystem "in a box" that enables data science at the tactical edge. Warfighters are able to process massive amounts of sensor data locally, without the need to transmit data to higher headquarters. Local processing allows for faster analysis and better decision-making in contested environments.
                  </p>
                  <a href="https://www.army.mil/article/288299/army_selects_six_winners_in_xtech_ai_grand_challenge_competition" target="_blank" rel="noopener noreferrer" className="cta-button">LEARN MORE</a>
                </div>
                <div className={styles.productImagesSingle}>
                  <img src="/images/soraka.png" alt="" className={styles.productSingleImage} />
                </div>
              </div>
            </div>

            <hr className="section-divider" />

            {/* Product 4: Viktor */}
            <div id="product4" className={`${styles.productSection} slide-up`}>
              <div className={styles.productContentAlt}>
                <div className={styles.productImagesSingle}>
                  <img src="/images/viktor.png" alt="" className={styles.productSingleImage} />
                </div>
                <div className={styles.productTextContent}>
                  <h2>Viktor</h2>
                  <p className={styles.productDescription}>
                    Improve decision-making for humanoid robots. Humanoid robot simulation platform built on a commercial game engine. Simulates Army individual and collective warrior tasks through a digital twin that mirrors physical robot actions and tasks. Takes generated COAs from Blue and simulates them at the individual level, ensuring robots not only execute tasks but also understand how their actions nest within higher-echelon missions.
                  </p>
                  <a href="" target="_blank" rel="noopener noreferrer" className="cta-button">Coming Soon</a>
                </div>
              </div>
            </div>
          </div>
        </section>

        <footer className="footer">
          <div className="container">
            <p>&copy; 2025 Exia Labs</p>
          </div>
        </footer>
      </div>
    </>
  )
}
